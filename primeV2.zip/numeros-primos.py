#Programa para conferir se um número é primo ou não

x = int(input("Digite seu número: "))
y = 2
if x % y != 0:
    y = 3
while x % y != 0 and y <= x:
    y = y + 2
if x == y:
    print("O número é primo")
else:
    print("O número não é primo, o proximo numero primo é: %s"%(x+2))

